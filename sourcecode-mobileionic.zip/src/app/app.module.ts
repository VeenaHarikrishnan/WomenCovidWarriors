import { BrowserModule } from '@angular/platform-browser';
import { ErrorHandler, NgModule } from '@angular/core';
import { IonicApp, IonicErrorHandler, IonicModule } from 'ionic-angular';
import { DataStore } from './dataStore';
import { MyApp } from './app.component';
import { HomePage } from '../pages/home/home';
import { LiveUpdateProvider } from '../providers/live-update/live-update';
import { StatusBar } from '@ionic-native/status-bar';
import { SplashScreen } from '@ionic-native/splash-screen';
import { LandingPagePage } from "../pages/LandingPage/LandingPage";
import { ParentLandingPage } from "../pages/ParentLanding/ParentLanding";
import { StudentLandingPage } from "../pages/StudentLanding/StudentLanding";
import { TeacherLandingPage } from "../pages/TeacherLanding/TeacherLanding";
import { ChatWithMePage } from "../pages/ChatWithMe/ChatWithMe";
import { OurWebsitePage } from "../pages/OurWebsite/OurWebsite";
import { StartupPage } from "../pages/Startup/Startup";
import { SocialResponsibilityPage } from "../pages/SocialResponsibility/SocialResponsibility";
import { DoctorServicesPage } from "../pages/DoctorServices/DoctorServices";
import { PhysicianPage } from "../pages/Physician/Physician";
import { CreateModalPage } from "../componentScripts/listViewCreateModal";
import { DetailModalPage } from "../componentScripts/listViewDetailModal";
import { SearchModalPage } from "../componentScripts/listViewSearchModal";
import { DonatePage } from "../pages/Donate/Donate";

@NgModule({
  declarations: [
    MyApp,
    HomePage
   ,LandingPagePage,ParentLandingPage,StudentLandingPage,TeacherLandingPage,ChatWithMePage,OurWebsitePage ,StartupPage,SocialResponsibilityPage   ,DoctorServicesPage      ,PhysicianPage   ,CreateModalPage,DetailModalPage,SearchModalPage,DonatePage],
  imports: [
    BrowserModule,
    IonicModule.forRoot(MyApp),
  ],
  bootstrap: [IonicApp],
  entryComponents: [
    MyApp,
    HomePage
   ,LandingPagePage,ParentLandingPage,StudentLandingPage,TeacherLandingPage,ChatWithMePage,OurWebsitePage ,StartupPage,SocialResponsibilityPage   ,DoctorServicesPage      ,PhysicianPage   ,CreateModalPage,DetailModalPage,SearchModalPage,DonatePage],
  providers: [
    StatusBar,
    SplashScreen,
    DataStore,
    {provide: ErrorHandler, useClass: IonicErrorHandler},
    LiveUpdateProvider
  ]
})
export class AppModule {}
