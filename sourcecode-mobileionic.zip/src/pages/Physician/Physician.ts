import { Component,Renderer,NgZone,NgModule } from '@angular/core';
import { NavController,ModalController, LoadingController } from 'ionic-angular';
import { DataStore } from '../../app/dataStore';
import {LiveUpdateProvider} from "../../providers/live-update/live-update";
import { DoctorServicesPage } from "../DoctorServices/DoctorServices";

@Component({
  selector: 'page-Physician',
  templateUrl: 'Physician.html'
})

@NgModule({
  providers: [
      LiveUpdateProvider
  ]
})

export class PhysicianPage {

  constructor(public navCtrl: NavController, public dataStore:DataStore, public liveUpdateService:LiveUpdateProvider) {

  }

    ionViewDidLoad() {
        WL.Analytics.log({ fromPage: this.navCtrl.getPrevious(this.navCtrl.getActive()).name, toPage: this.navCtrl.getActive().name }, 'PageTransition ');
        WL.Analytics.send();
    }

    Physician_Image_1183_clickHandler() {
        this.navCtrl.push( DoctorServicesPage, {
                data: {"a":"a"}
              });
    }
}