import { Component,Renderer,NgZone,NgModule } from '@angular/core';
import { NavController,ModalController, LoadingController } from 'ionic-angular';
import { DataStore } from '../../app/dataStore';
import {LiveUpdateProvider} from "../../providers/live-update/live-update";
import { DonatePage } from "../Donate/Donate";

@Component({
  selector: 'page-SocialResponsibility',
  templateUrl: 'SocialResponsibility.html'
})

@NgModule({
  providers: [
      LiveUpdateProvider
  ]
})

export class SocialResponsibilityPage {

  constructor(public navCtrl: NavController, public dataStore:DataStore, public liveUpdateService:LiveUpdateProvider) {

  }

    ionViewDidLoad() {
        WL.Analytics.log({ fromPage: this.navCtrl.getPrevious(this.navCtrl.getActive()).name, toPage: this.navCtrl.getActive().name }, 'PageTransition ');
        WL.Analytics.send();
    }

    SocialResponsibility_Image_6652_clickHandler() {
        this.navCtrl.push( DonatePage, {
                data: {"a":"a"}
              });
    }
}