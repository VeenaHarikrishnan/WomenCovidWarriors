import { Component,Renderer,NgZone,NgModule } from '@angular/core';
import { NavController,ModalController, LoadingController } from 'ionic-angular';
import { DataStore } from '../../app/dataStore';
import {LiveUpdateProvider} from "../../providers/live-update/live-update";
import { ParentLandingPage } from "../ParentLanding/ParentLanding";
import { StudentLandingPage } from "../StudentLanding/StudentLanding";
import { TeacherLandingPage } from "../TeacherLanding/TeacherLanding";

@Component({
  selector: 'page-LandingPage',
  templateUrl: 'LandingPage.html'
})

@NgModule({
  providers: [
      LiveUpdateProvider
  ]
})

export class LandingPagePage {

  constructor(public navCtrl: NavController, public dataStore:DataStore, public liveUpdateService:LiveUpdateProvider) {

  }

    ionViewDidLoad() {
        WL.Analytics.log({ fromPage: this.navCtrl.getPrevious(this.navCtrl.getActive()).name, toPage: this.navCtrl.getActive().name }, 'PageTransition ');
        WL.Analytics.send();
    }

    LandingPage_Image_1854_clickHandler() {
        this.navCtrl.push( ParentLandingPage, {
                data: {"a":"a"}
              });
    }

    LandingPage_Image_2025_clickHandler() {
        this.navCtrl.push( StudentLandingPage, {
                data: {"a":"a"}
              });
    }

    LandingPage_Image_2490_clickHandler() {
        this.navCtrl.push( TeacherLandingPage, {
                data: {"a":"a"}
              });
    }
}