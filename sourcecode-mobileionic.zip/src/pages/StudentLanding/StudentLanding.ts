import { Component,Renderer,NgZone,NgModule } from '@angular/core';
import { NavController,ModalController, LoadingController } from 'ionic-angular';
import { DataStore } from '../../app/dataStore';
import {LiveUpdateProvider} from "../../providers/live-update/live-update";
import { ChatWithMePage } from "../ChatWithMe/ChatWithMe";
import { OurWebsitePage } from "../OurWebsite/OurWebsite";

@Component({
  selector: 'page-StudentLanding',
  templateUrl: 'StudentLanding.html'
})

@NgModule({
  providers: [
      LiveUpdateProvider
  ]
})

export class StudentLandingPage {

  constructor(public navCtrl: NavController, public dataStore:DataStore, public liveUpdateService:LiveUpdateProvider) {

  }

    ionViewDidLoad() {
        WL.Analytics.log({ fromPage: this.navCtrl.getPrevious(this.navCtrl.getActive()).name, toPage: this.navCtrl.getActive().name }, 'PageTransition ');
        WL.Analytics.send();
    }

    StudentLanding_Image_6321_clickHandler() {
        this.navCtrl.push( ChatWithMePage, {
                data: {"a":"a"}
              });
    }

    StudentLanding_Image_832_clickHandler() {
        this.navCtrl.push( OurWebsitePage, {
                data: {"a":"a"}
              });
    }

    StudentLanding_Image_6774_clickHandler() {
        this.navCtrl.push( OurWebsitePage, {
                data: {"a":"a"}
              });
    }
}