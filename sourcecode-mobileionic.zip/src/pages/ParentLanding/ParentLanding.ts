import { Component,Renderer,NgZone,NgModule } from '@angular/core';
import { NavController,ModalController, LoadingController } from 'ionic-angular';
import { DataStore } from '../../app/dataStore';
import {LiveUpdateProvider} from "../../providers/live-update/live-update";
import { StartupPage } from "../Startup/Startup";
import { SocialResponsibilityPage } from "../SocialResponsibility/SocialResponsibility";
import { PhysicianPage } from "../Physician/Physician";

@Component({
  selector: 'page-ParentLanding',
  templateUrl: 'ParentLanding.html'
})

@NgModule({
  providers: [
      LiveUpdateProvider
  ]
})

export class ParentLandingPage {

  constructor(public navCtrl: NavController, public dataStore:DataStore, public liveUpdateService:LiveUpdateProvider) {

  }

    ionViewDidLoad() {
        WL.Analytics.log({ fromPage: this.navCtrl.getPrevious(this.navCtrl.getActive()).name, toPage: this.navCtrl.getActive().name }, 'PageTransition ');
        WL.Analytics.send();
    }

    ParentLanding_Image_4191_clickHandler() {
        this.navCtrl.push( StartupPage, {
                data: {"a":"a"}
              });
    }

    ParentLanding_Image_6180_clickHandler() {
        this.navCtrl.push( SocialResponsibilityPage, {
                data: {"a":"a"}
              });
    }

    ParentLanding_Image_6399_clickHandler() {
        this.navCtrl.push( PhysicianPage, {
                data: {"a":"a"}
              });
    }
}