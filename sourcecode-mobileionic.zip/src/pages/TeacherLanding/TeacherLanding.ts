import { Component,Renderer,NgZone,NgModule } from '@angular/core';
import { NavController,ModalController, LoadingController } from 'ionic-angular';
import { DataStore } from '../../app/dataStore';
import {LiveUpdateProvider} from "../../providers/live-update/live-update";
import { OurWebsitePage } from "../OurWebsite/OurWebsite";

@Component({
  selector: 'page-TeacherLanding',
  templateUrl: 'TeacherLanding.html'
})

@NgModule({
  providers: [
      LiveUpdateProvider
  ]
})

export class TeacherLandingPage {

  constructor(public navCtrl: NavController, public dataStore:DataStore, public liveUpdateService:LiveUpdateProvider) {

  }

    ionViewDidLoad() {
        WL.Analytics.log({ fromPage: this.navCtrl.getPrevious(this.navCtrl.getActive()).name, toPage: this.navCtrl.getActive().name }, 'PageTransition ');
        WL.Analytics.send();
    }

    TeacherLanding_Image_8062_clickHandler() {
        this.navCtrl.push( OurWebsitePage, {
                data: {"a":"a"}
              });
    }

    TeacherLanding_Image_646_clickHandler() {
        this.navCtrl.push( OurWebsitePage, {
                data: {"a":"a"}
              });
    }

    TeacherLanding_Image_295_clickHandler() {
        this.navCtrl.push( OurWebsitePage, {
                data: {"a":"a"}
              });
    }
}