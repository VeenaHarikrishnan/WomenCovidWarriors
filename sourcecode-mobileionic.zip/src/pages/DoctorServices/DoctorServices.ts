import { Component,Renderer,NgZone,NgModule } from '@angular/core';
import { NavController,ModalController, LoadingController } from 'ionic-angular';
import { DataStore } from '../../app/dataStore';
import {LiveUpdateProvider} from "../../providers/live-update/live-update";
import ListComponent from "../../componentScripts/listView";
import { CreateModalPage } from "../../componentScripts/listViewCreateModal";
import { DetailModalPage } from "../../componentScripts/listViewDetailModal";
import { SearchModalPage } from "../../componentScripts/listViewSearchModal";

@Component({
  selector: 'page-DoctorServices',
  templateUrl: 'DoctorServices.html'
})

@NgModule({
  providers: [
      LiveUpdateProvider
  ]
})

export class DoctorServicesPage {

  constructor(public navCtrl: NavController, public dataStore:DataStore, public liveUpdateService:LiveUpdateProvider, renderer: Renderer, private zone: NgZone, public modalCtrl: ModalController, public loadingCtrl: LoadingController) {
      let loader = this.loadingCtrl.create({});
      const searchAttributes = this.getSearchAttributes();
      this.listInputAttributes = this.listViewComponent.getDetailAttributesList({}, searchAttributes, false);
      if(this.dataset){ loader.present();  this.listViewComponent.callAPI(this.baseurl, WLResourceRequest.GET, this.GETLISTPATH, this.listInputAttributes, (err,response) => { this.zone.run(() => { loader.dismiss(); this.responseList=JSON.parse(response); this.filterList=this.responseList;}); });}
  }

    ionViewDidLoad() {
        WL.Analytics.log({ fromPage: this.navCtrl.getPrevious(this.navCtrl.getActive()).name, toPage: this.navCtrl.getActive().name }, 'PageTransition ');
        WL.Analytics.send();
    }

    listTitle: '';
    responseList: any;
    filterList: any;
    filterBy = 'All';
    listViewComponent = new ListComponent();
    dataset = '';
    title = [];
    subtitle = [];
    image = [];
    listInputAttributes = [];
    addAttributes = [];
    editAttributes = [];
    viewAttributes = [];
    GETLISTPATH: any;
    GETVIEWPATH: any;
    PUTEDITPATH: any;
    DELETEPATH: any;
    POSTADDPATH: any;
    status = [];
    baseurl = '';
    filterAttribute = 'false';

    openCreateModal() {
        let createModal = this.modalCtrl.create(CreateModalPage, { formItems: this.addAttributes, baseurl: this.baseurl, adapterPath: this.POSTADDPATH });createModal.onDidDismiss(() => {this.responseList=null;this.listViewComponent.callAPI(this.baseurl, WLResourceRequest.GET, this.GETLISTPATH, this.listInputAttributes, (err,response) => { this.zone.run(() => {this.responseList=JSON.parse(response);this.filterList=this.responseList;}); });});createModal.present();
    }

    openViewModal(page, item) {
        if(this.checkPermission(page)) {const modalInput = {postPathURL: this.POSTADDPATH,viewPathURL: this.GETVIEWPATH,editPathURL: this.PUTEDITPATH,deletePathURL: this.DELETEPATH,baseurl: this.baseurl,viewItem: {},viewAttributes: this.viewAttributes,editAttributes: this.editAttributes,addAttributes: this.addAttributes,viewTitle: this.title,showPage: 'view'};if(page === 'view') {let loader = this.loadingCtrl.create({});loader.present();let params = this.listViewComponent.getDetailAttributesList(item, this.viewAttributes, false);this.listViewComponent.callAPI(this.baseurl, WLResourceRequest.GET, this.GETVIEWPATH, params, (err,response) => {this.zone.run(() => {loader.dismiss();const viewResponse=JSON.parse(response);modalInput.viewItem = viewResponse;this.openItemModal(modalInput);});});} else {modalInput.showPage = 'add';this.openItemModal(modalInput)}}
    }

    openItemModal(modalInput) {
        let detailModal = this.modalCtrl.create(DetailModalPage, modalInput);detailModal.onDidDismiss(() => {this.responseList=null;let loader = this.loadingCtrl.create({});loader.present();this.listViewComponent.callAPI(this.baseurl,WLResourceRequest.GET,this.GETLISTPATH,this.listInputAttributes, (err,response) => { this.zone.run(() => { loader.dismiss();this.responseList=JSON.parse(response);this.filterList=this.responseList; });});});detailModal.present();
    }

    getDisplayValue(item, attributeList) {
        return this.listViewComponent.getDisplayValue(item, attributeList);
    }

    showDynamicImage() {
        if(this.image && this.image.length > 0) {const imageItem = this.image[0];if(imageItem.key === 'dynamic') { return '1'; } else { return '0'; }} else { return '2'; }
    }

    isShowStatusImage(item) {
        let isShowImage = false;this.status.map((attribute) => {if(attribute.key === 'dynamic') {const {value} = attribute;if(attribute.displayType === 'image') {const nestedAttrList = value.split('.');let attrValue = item;nestedAttrList.map((attr, index) => { attrValue = attrValue[attr];});const {tagImagesObj}= attribute;if(tagImagesObj[attrValue]) {isShowImage= true;}}}});return isShowImage;
    }

    getStatusImage(item) {
        let imageSrc = '';this.status.map((attribute) => {if(attribute.key === 'dynamic') {const {value} = attribute;if(attribute.displayType === 'image') {const nestedAttrList = value.split('.');let attrValue = item;nestedAttrList.map((attr, index) => { attrValue = attrValue[attr];});const {tagImagesObj}= attribute;if(tagImagesObj[attrValue]) {imageSrc = 'assets/imgs/statusIcons/'+tagImagesObj[attrValue];}}}});return imageSrc;
    }

    getFilterKeys() {
        let filterList = ['All'];if(this.status.length > 0) {this.status.map((attribute) => {if(attribute.enum && attribute.enum.length > 0) {attribute.enum.map((enumvale) => {filterList.push(enumvale);});}});}return filterList;
    }

    filterListAction($event) {
        this.filterList =[];if( $event === 'All') {this.filterList = this.responseList;} else {this.responseList.map((listItem) => {const statusVal = this.getDisplayValue(listItem, this.status);if(statusVal.toString() === $event) {this.filterList.push(listItem);}});}
    }

    checkPermission(actionType) {
        if(actionType === 'add') {if(this.POSTADDPATH) {return true;}} else if(actionType === 'view') {if(this.GETVIEWPATH) {return true;}}return false;
    }

    openSearchModal() {
        const searchAttributes = this.getSearchAttributes();const modalInput = {searchAttributes};let searchModal = this.modalCtrl.create(SearchModalPage, modalInput);searchModal.onDidDismiss((inputAttributes) => {if(inputAttributes) {this.listInputAttributes = inputAttributes;this.responseList=null;let loader = this.loadingCtrl.create({});loader.present();this.filterBy = 'All';this.listViewComponent.callAPI(this.baseurl,WLResourceRequest.GET,this.GETLISTPATH,this.listInputAttributes, (err,response) => { this.zone.run(() => { loader.dismiss();this.responseList=JSON.parse(response);this.filterList=this.responseList;});});}});searchModal.present();
    }

    checkIsSearchable() {
        const searchAttributes = this.getSearchAttributes();if(searchAttributes.length > 0) {return true;}return false;
    }

    getSearchAttributes() {
        let attributesList = [];if(this.GETLISTPATH) {const verbObj = this.GETLISTPATH.verbRequestInfo;if(verbObj) {const queryAttributes = verbObj.queryAttributes;const pathAttributes = verbObj.pathAttributes;attributesList = queryAttributes.concat(pathAttributes);}}return attributesList;
    }

    ListtypeId = "listType_1";
}